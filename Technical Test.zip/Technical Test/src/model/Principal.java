package model;

import javax.swing.SwingUtilities;

import view.Window;
import controller.ButtonController;
import controller.ButtonController;


public class Principal {
	
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				//Create the view
				Window view = new Window();
				//Create the model
				BasketService service = new BasketService();
				//Create the button controller
				ButtonController bc = new ButtonController(view,service);
				//We assign the buttons of the view to the Button Controller
				view.assignButtonController(bc);
				view.setVisible(true);				
			}
		});
	}

}
