package model;

import java.text.DecimalFormat;

import javax.swing.JLabel;

import view.Window;

public class BasketService {
	
	public BasketService(){
	}
	
	public String calculateFinalPrice(String butter, String milk, String bread){
		
		int nButter = Integer.parseInt(butter);
		int nMilk = Integer.parseInt(milk);
		int nBread = Integer.parseInt(bread);
		
		//Look for the discounts on Bread (which depends on the Butter items)
		int nDiscountsBread = 0;
		for(int i=nButter;i>=2;i=i-2){
			nDiscountsBread++;		
		}
		
		//Look for the discounts on Milk (which depends on the Milk items)
		int nDiscountsMilk = 0;
		for(int i=nMilk;i>=3;i=i-3){
			nDiscountsMilk++;
		}
		
		//Butter price
		double dTotalButter = nButter*0.80;
		
		//Milk discounts
		double dTotalMilk = nMilk*1.15;
		for(int i=nDiscountsMilk;i>0;i--){
			if(nMilk <4){
				i = 0;
			}else{
				dTotalMilk = dTotalMilk - 1.15;
			}
		}
		
		//Bread discount
		double dTotalBread = nBread*1.00;
		int nRestBread = nBread;
		for(int i=nDiscountsBread;i>0;i--){
			if(nRestBread == 0){
				i = 0;
			}else{
				dTotalBread = dTotalBread - 0.50;
				nRestBread = nRestBread - 1;
			}
		}
		//We calculate the final cost of the customer basket
		double dTotalPrice = dTotalButter + dTotalMilk + dTotalBread;
		DecimalFormat decim = new DecimalFormat("0.00");
		
		return(decim.format(dTotalPrice).replace(",", "."));
		
	}

}
