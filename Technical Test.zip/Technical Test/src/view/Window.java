package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.ButtonController;

public class Window extends JFrame{
	
	private JPanel jpGlobal;
	
	private JPanel jpTop;
	private JPanel jpTop2;
	private JPanel jpTop3;
	private JPanel jpCentre;
	private JPanel jpBelow;
	
	private JPanel jpButter;
	private JPanel jpMilk;
	private JPanel jpBread;
	
	private JLabel jlButter;
	private JLabel jlMilk;
	private JLabel jlBread;
	
	private JLabel jlPhotoButter;
	private JLabel jlPhotoMilk;
	private JLabel jlPhotoBread;
	
	private JLabel jlPriceButter;
	private JLabel jlPriceMilk;
	private JLabel jlPriceBread;
	
	private JPanel jpQuantButter;
	private JPanel jpQuantMilk;
	private JPanel jpQuantBread;
	
	private JLabel jlQuantButter;
	private JLabel jlQuantMilk;
	private JLabel jlQuantBread;
	
	private JComboBox jcButter;
	private JComboBox jcMilk;
	private JComboBox jcBread;
	
	private JButton jbBuy;
	
	private JLabel jlFinalPrice;
	
	public Window(){
		
		super();
		
		jpTop = new JPanel();
		jpTop.setLayout(new GridLayout(1,3));
		
		//Text and photo of Butter
		jpButter = new JPanel();
		jpButter.setLayout(new BorderLayout());
		
		Font font = new Font("Courier", Font.BOLD,30);
		jlButter = new JLabel("Butter");
		jlButter.setHorizontalAlignment(jlButter.CENTER);
		jlButter.setFont(font);
		
		jlPhotoButter = new JLabel(new ImageIcon("butter.jpg"));
		jlPhotoButter.setHorizontalAlignment(JLabel.CENTER);
		jlPhotoButter.setFont(jlPhotoButter.getFont().deriveFont((float)50));
		jlPhotoButter.setAlignmentX(Component.CENTER_ALIGNMENT);

		jpButter.add(jlButter,BorderLayout.PAGE_START);
		jpButter.add(jlPhotoButter,BorderLayout.CENTER);
		
		//Text and photo of Milk
		jpMilk = new JPanel();
		jpMilk.setLayout(new BorderLayout());
		
		jlMilk = new JLabel("Milk");
		jlMilk.setHorizontalAlignment(jlMilk.CENTER);
		jlMilk.setFont(font);
		
		jlPhotoMilk = new JLabel(new ImageIcon("milk.jpg"));
		jlPhotoMilk.setHorizontalAlignment(JLabel.CENTER);
		jlPhotoMilk.setFont(jlPhotoButter.getFont().deriveFont((float)50));
		jlPhotoMilk.setAlignmentX(Component.CENTER_ALIGNMENT);

		jpMilk.add(jlMilk,BorderLayout.PAGE_START);
		jpMilk.add(jlPhotoMilk,BorderLayout.CENTER);
		
		//Text and photo of Bread
		jpBread = new JPanel();
		jpBread.setLayout(new BorderLayout());
		
		jlBread = new JLabel("Bread");
		jlBread.setHorizontalAlignment(jlBread.CENTER);
		jlBread.setFont(font);
		
		jlPhotoBread = new JLabel(new ImageIcon("bread.jpg"));
		jlPhotoBread.setHorizontalAlignment(JLabel.CENTER);
		jlPhotoBread.setFont(jlPhotoBread.getFont().deriveFont((float)50));
		jlPhotoBread.setAlignmentX(Component.CENTER_ALIGNMENT);

		jpBread.add(jlBread,BorderLayout.PAGE_START);
		jpBread.add(jlPhotoBread,BorderLayout.CENTER);
		
		jpTop.add(jpButter);
		jpTop.add(jpMilk);
		jpTop.add(jpBread);
		
		//We create the 3 little JPanels to show the price of each product.
		jpTop3 = new JPanel();
		jpTop3.setLayout(new GridLayout(1,3));
		
		font = new Font("Courier", Font.BOLD,20);
		jlPriceButter = new JLabel("Price: £0.80");
		jlPriceButter.setHorizontalAlignment(JLabel.CENTER);
		jlPriceButter.setFont(font);
		
		jlPriceMilk = new JLabel("Price: £1.15");
		jlPriceMilk.setHorizontalAlignment(JLabel.CENTER);
		jlPriceMilk.setFont(font);
		
		jlPriceBread = new JLabel("Price: £1.00");
		jlPriceBread.setHorizontalAlignment(JLabel.CENTER);
		jlPriceBread.setFont(font);
		
		jpTop3.add(jlPriceButter);
		jpTop3.add(jlPriceMilk);
		jpTop3.add(jlPriceBread);
		
		//We create the 3 little JPanels to select the quantity of each product. Each ones contains a JLabel and JComboBox
		jpTop2 = new JPanel();
		jpTop2.setLayout(new GridLayout(1,3));
		
		jpQuantButter = new JPanel();
		jpQuantMilk = new JPanel();
		jpQuantBread = new JPanel();
		
		jlQuantButter = new JLabel("Quantity");
		jlQuantMilk = new JLabel("Quantity");
		jlQuantBread = new JLabel("Quantity");
		String[] quant = {"0","1","2","3","4","5","6","7","8","9","10"};

		jcButter = new JComboBox(quant);
		jcMilk = new JComboBox(quant);
		jcBread = new JComboBox(quant);
		
		jpQuantButter.add(jlQuantButter);
		jpQuantButter.add(jcButter);
		jpQuantMilk.add(jlQuantMilk);
		jpQuantMilk.add(jcMilk);
		jpQuantBread.add(jlQuantBread);
		jpQuantBread.add(jcBread);
		
		jpTop2.add(jpQuantButter);
		jpTop2.add(jpQuantMilk);
		jpTop2.add(jpQuantBread);
		jpTop2.setAlignmentX(CENTER_ALIGNMENT);
		
		//Center JPanel, which only contains a JButton to purchase the selected items
		jpCentre = new JPanel();
		
		jbBuy = new JButton("BUY!");
		jbBuy.setPreferredSize(new Dimension(200,70));
		jbBuy.setFont(jbBuy.getFont().deriveFont((float)40));
		jbBuy.setHorizontalAlignment(JButton.CENTER);
		jbBuy.setVerticalAlignment(JButton.CENTER);
		jpCentre.add(jbBuy);
		jpCentre.setAlignmentY(CENTER_ALIGNMENT);
		
		//Bottom JPanel, which contains a JLabel with the final price
		jpBelow = new JPanel();
		
		jlFinalPrice = new JLabel("Final Price = £0.00");
		jlFinalPrice.setHorizontalAlignment(JLabel.CENTER);
		jlFinalPrice.setFont(jlFinalPrice.getFont().deriveFont((float)20));
		
		jpBelow.add(jlFinalPrice);
		jpBelow.setBackground(Color.YELLOW);
		
		//Global JPanel
		jpGlobal = new JPanel();
		jpGlobal.setLayout(new BoxLayout(jpGlobal, BoxLayout.Y_AXIS));
		jpGlobal.add(jpTop);
		jpGlobal.add(Box.createRigidArea(new Dimension(0,20)));
		jpGlobal.add(jpTop3);
		jpGlobal.add(jpTop2);
		jpGlobal.add(jpCentre);
		jpGlobal.add(jpBelow);
		jpGlobal.setBorder(BorderFactory.createTitledBorder("Customer Basket"));
		
		this.getContentPane().add(jpGlobal);
		
		this.setSize(1000, 500);
		this.setTitle("Customer Basket");
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public void assignButtonController(ButtonController bc){
		jbBuy.addActionListener(bc);
	}

	public JPanel getJpGlobal() {
		return jpGlobal;
	}

	public void setJpGlobal(JPanel jpGlobal) {
		this.jpGlobal = jpGlobal;
	}

	public JPanel getJpTop() {
		return jpTop;
	}

	public void setJpTop(JPanel jpTop) {
		this.jpTop = jpTop;
	}

	public JPanel getJpTop2() {
		return jpTop2;
	}

	public void setJpTop2(JPanel jpTop2) {
		this.jpTop2 = jpTop2;
	}

	public JPanel getJpTop3() {
		return jpTop3;
	}

	public void setJpTop3(JPanel jpTop3) {
		this.jpTop3 = jpTop3;
	}

	public JPanel getJpCentre() {
		return jpCentre;
	}

	public void setJpCentre(JPanel jpCentre) {
		this.jpCentre = jpCentre;
	}

	public JPanel getJpBelow() {
		return jpBelow;
	}

	public void setJpBelow(JPanel jpBelow) {
		this.jpBelow = jpBelow;
	}

	public JPanel getJpButter() {
		return jpButter;
	}

	public void setJpButter(JPanel jpButter) {
		this.jpButter = jpButter;
	}

	public JPanel getJpMilk() {
		return jpMilk;
	}

	public void setJpMilk(JPanel jpMilk) {
		this.jpMilk = jpMilk;
	}

	public JPanel getJpBread() {
		return jpBread;
	}

	public void setJpBread(JPanel jpBread) {
		this.jpBread = jpBread;
	}

	public JLabel getJlButter() {
		return jlButter;
	}

	public void setJlButter(JLabel jlButter) {
		this.jlButter = jlButter;
	}

	public JLabel getJlMilk() {
		return jlMilk;
	}

	public void setJlMilk(JLabel jlMilk) {
		this.jlMilk = jlMilk;
	}

	public JLabel getJlBread() {
		return jlBread;
	}

	public void setJlBread(JLabel jlBread) {
		this.jlBread = jlBread;
	}

	public JLabel getJlPhotoButter() {
		return jlPhotoButter;
	}

	public void setJlPhotoButter(JLabel jlPhotoButter) {
		this.jlPhotoButter = jlPhotoButter;
	}

	public JLabel getJlPhotoMilk() {
		return jlPhotoMilk;
	}

	public void setJlPhotoMilk(JLabel jlPhotoMilk) {
		this.jlPhotoMilk = jlPhotoMilk;
	}

	public JLabel getJlPhotoBread() {
		return jlPhotoBread;
	}

	public void setJlPhotoBread(JLabel jlPhotoBread) {
		this.jlPhotoBread = jlPhotoBread;
	}

	public JLabel getJlPriceButter() {
		return jlPriceButter;
	}

	public void setJlPriceButter(JLabel jlPriceButter) {
		this.jlPriceButter = jlPriceButter;
	}

	public JLabel getJlPriceMilk() {
		return jlPriceMilk;
	}

	public void setJlPriceMilk(JLabel jlPriceMilk) {
		this.jlPriceMilk = jlPriceMilk;
	}

	public JLabel getJlPriceBread() {
		return jlPriceBread;
	}

	public void setJlPriceBread(JLabel jlPriceBread) {
		this.jlPriceBread = jlPriceBread;
	}

	public JPanel getJpQuantButter() {
		return jpQuantButter;
	}

	public void setJpQuantButter(JPanel jpQuantButter) {
		this.jpQuantButter = jpQuantButter;
	}

	public JPanel getJpQuantMilk() {
		return jpQuantMilk;
	}

	public void setJpQuantMilk(JPanel jpQuantMilk) {
		this.jpQuantMilk = jpQuantMilk;
	}

	public JPanel getJpQuantBread() {
		return jpQuantBread;
	}

	public void setJpQuantBread(JPanel jpQuantBread) {
		this.jpQuantBread = jpQuantBread;
	}

	public JLabel getJlQuantButter() {
		return jlQuantButter;
	}

	public void setJlQuantButter(JLabel jlQuantButter) {
		this.jlQuantButter = jlQuantButter;
	}

	public JLabel getJlQuantMilk() {
		return jlQuantMilk;
	}

	public void setJlQuantMilk(JLabel jlQuantMilk) {
		this.jlQuantMilk = jlQuantMilk;
	}

	public JLabel getJlQuantBread() {
		return jlQuantBread;
	}

	public void setJlQuantBread(JLabel jlQuantBread) {
		this.jlQuantBread = jlQuantBread;
	}

	public JComboBox getJcButter() {
		return jcButter;
	}

	public void setJcButter(JComboBox jcButter) {
		this.jcButter = jcButter;
	}

	public JComboBox getJcMilk() {
		return jcMilk;
	}

	public void setJcMilk(JComboBox jcMilk) {
		this.jcMilk = jcMilk;
	}

	public JComboBox getJcBread() {
		return jcBread;
	}

	public void setJcBread(JComboBox jcBread) {
		this.jcBread = jcBread;
	}

	public JButton getJbBuy() {
		return jbBuy;
	}

	public void setJbBuy(JButton jbBuy) {
		this.jbBuy = jbBuy;
	}

	public JLabel getJlFinalPrice() {
		return jlFinalPrice;
	}

	public void setJlFinalPrice(JLabel jlFinalPrice) {
		this.jlFinalPrice = jlFinalPrice;
	}
	
	

}
