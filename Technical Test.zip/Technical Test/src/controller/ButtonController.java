package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;

import model.BasketService;
import view.Window;

public class ButtonController implements ActionListener{

	private Window view;
	private BasketService service;
	
	
	public ButtonController(Window view, BasketService service){
		this.view = view;
		this.service = service;
	}
	
	public void actionPerformed(ActionEvent e){
		
		//ButtonController of the Buy button
		if(e.getSource().equals(view.getJbBuy())){
			//We read the quantity of each product
			String butter = view.getJcButter().getSelectedItem().toString();
			String milk = view.getJcMilk().getSelectedItem().toString();
			String bread = view.getJcBread().getSelectedItem().toString();
			//We calculate the final cost of the basket
			String finalPrice = service.calculateFinalPrice(butter, milk, bread);
			//We show in the main windows the final cost
			JLabel label = view.getJlFinalPrice();
			label.setText("Final Price = £"+finalPrice);
			view.setJlFinalPrice(label);
		}
	}
}
